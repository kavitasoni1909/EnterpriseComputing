package com.ec.project;

import java.io.IOException;
import java.io.PrintWriter;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/predict")
public class EJBStatelessServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@EJB
	private EJBStatelessLocal lrs;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();

		try {
			out.println("KNN Predict");
			out.println("<br>");
			String age = request.getParameter("age");
			String sex = request.getParameter("sex");
			String chestPain = request.getParameter("chestPain");
			String trestbps = request.getParameter("trestbps");
			String cholestrol = request.getParameter("cholestrol");
			String fbs = request.getParameter("fbs");
			String restecg = request.getParameter("restecg");
			String thalach = request.getParameter("thalach");
			String exang = request.getParameter("exang");
			String slope = request.getParameter("slope");
			String ca = request.getParameter("ca");
			String oldpeak = request.getParameter("oldpeak");
			String thal = request.getParameter("thal");

			String result = lrs.predict(Integer.parseInt(age), sex == "male" ? 1 : 0, Integer.parseInt(chestPain),
					Integer.parseInt(trestbps), Integer.parseInt(cholestrol), Integer.parseInt(fbs),
					Integer.parseInt(restecg), Integer.parseInt(thalach), Integer.parseInt(exang),
					Integer.parseInt(oldpeak), Integer.parseInt(slope), Integer.parseInt(ca), Integer.parseInt(thal));

			String reply = result.equals("0.0") ? "Hey! You are Fit. Stay Healthy"
					: "Sorry ! You are vulnerable or might have a heart disease. Kindly consult a heart doctor";

			PrintWriter writer = response.getWriter();

			// build HTML code
			String htmlRespone = "<html>  <head>\r\n" + "    <meta charset=\"utf-8\">\r\n" + "    <title></title>\r\n"
					+ "    <link rel=\"stylesheet\" href=\"style.css\">\r\n" + "     \r\n" + "  </head>\r\n"
					+ "  <body>";
			htmlRespone += "<h2>Prediction Result is: " + reply + "</h2>";
			htmlRespone += "</body></html>";

			// return response
			writer.println(htmlRespone);

		} catch (Exception ex) {
			throw new ServletException(ex);
		} finally {
			out.close();
		}
	}
}
