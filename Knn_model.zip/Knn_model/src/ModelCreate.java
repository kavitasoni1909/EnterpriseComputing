
/* check Weka wiki for more detail on using weka library with java
https://weka.wikispaces.com/Use%20Weka%20in%20your%20Java%20code#Classifying%20instances
*/

import java.io.BufferedReader;
import java.io.FileReader;

import weka.classifiers.Classifier;
import weka.classifiers.lazy.IBk;
import weka.core.Instances;

public class ModelCreate {

	public static void main(String[] args) throws Exception {
		String DATA_PATH = "data/";
		String MODEL_PATH = "Model22/";

		Classifier cls = new IBk(3);

		Instances inst = new Instances(new BufferedReader(new FileReader(DATA_PATH + "heart.arff")));
		inst.setClassIndex(inst.numAttributes() - 1);
		cls.buildClassifier(inst);

		weka.core.SerializationHelper.write(MODEL_PATH + "heart_model.bin", cls);
		System.out.println("Model Made");

		// prediction
		Classifier cls1 = (Classifier) weka.core.SerializationHelper.read(MODEL_PATH + "heart_model.bin");
		Instances instances = new Instances(new BufferedReader(new FileReader(DATA_PATH + "heart_unknown.arff")));
		instances.setClassIndex(inst.numAttributes() - 1);
		double value = cls1.classifyInstance(instances.firstInstance());

		System.out.println("Predicted value: " + value);
	}
}